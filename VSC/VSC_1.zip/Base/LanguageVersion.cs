﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSC
{
    public enum LanguageVersion
    {
        V_1 = 1,
        Experimental = 100,

        Default = LanguageVersion.V_1,
    }
}
