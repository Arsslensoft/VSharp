using System;

namespace VSC.TypeSystem
{
    [Obsolete("IParsedFile was renamed to IUnresolvedFile", true)]
    public interface IParsedFile {}
}