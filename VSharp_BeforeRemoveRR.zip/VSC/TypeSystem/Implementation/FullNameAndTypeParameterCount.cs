using System;
using System.Collections.Generic;

namespace VSC.TypeSystem.Implementation
{
	[Obsolete("This struct was renamed to 'TopLevelTypeName'.", true)]
	public struct FullNameAndTypeParameterCount
	{
	}
}
