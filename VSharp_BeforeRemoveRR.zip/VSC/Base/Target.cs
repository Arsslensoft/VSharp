namespace VSC
{
    public enum Target
    {
        flat,
        tiny,
        vexe,
        obj
    }
}