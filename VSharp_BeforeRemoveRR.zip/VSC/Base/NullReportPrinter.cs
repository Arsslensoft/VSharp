namespace VSC
{
    sealed class NullReportPrinter : ReportPrinter
    {
    }
}