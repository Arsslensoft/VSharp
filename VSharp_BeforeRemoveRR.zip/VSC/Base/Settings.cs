using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VSC
{
    public enum Platform
    {
        Intel16,
        x86
    }
}
