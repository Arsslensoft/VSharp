namespace VSC.AST {
public class Break : LocalExitStatement
	{		
		public Break (Location l)
			: base (l)
		{
		}
		
		
	}


}