namespace VSC.AST {
/// <summary>
	///   `goto default' statement
	/// </summary>
	public class GotoDefault : SwitchGoto
	{		
		public GotoDefault (Location l)
			: base (l)
		{
		}

	
	}


}