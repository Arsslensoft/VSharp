namespace VSC.AST {
public class Continue : LocalExitStatement
	{		
		public Continue (Location l)
			: base (l)
		{
		}

	}



}