namespace VSC.AST {
public class BlockConstant : BlockVariable
	{
		public BlockConstant (FullNamedExpression type, LocalVariable li)
			: base (type, li)
		{
		}

	}


}