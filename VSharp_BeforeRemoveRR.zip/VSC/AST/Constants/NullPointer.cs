namespace VSC.AST
{
    class NullPointer : NullConstant
    {
        public NullPointer (Location loc)
            : base (loc)
        {
        }

	

	
    }
}