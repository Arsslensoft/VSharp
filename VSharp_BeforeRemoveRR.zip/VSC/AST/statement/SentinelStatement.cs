namespace VSC.AST {

class SentinelStatement: Statement
	{
	/*	protected override void CloneTo (CloneContext clonectx, Statement target)
		{
		}

		protected override void DoEmit (EmitContext ec)
		{
			var l = ec.DefineLabel ();
			ec.MarkLabel (l);
			ec.Emit (OpCodes.Br_S, l);
		}

		protected override bool DoFlowAnalysis (FlowAnalysisContext fc)
		{
			throw new NotImplementedException ();
		}*/
	}


}