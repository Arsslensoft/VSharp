namespace VSC.AST {
public class BlockVariableDeclarator
	{
		/*LocalVariable li;
		Expression initializer;

		public BlockVariableDeclarator (LocalVariable li, Expression initializer)
		{
			if (li.Type != null)
				throw new ArgumentException ("Expected null variable type");

			this.li = li;
			this.initializer = initializer;
		}

		#region Properties

		public LocalVariable Variable {
			get {
				return li;
			}
		}

		public Expression Initializer {
			get {
				return initializer;
			}
			set {
				initializer = value;
			}
		}

		#endregion

		public virtual BlockVariableDeclarator Clone (CloneContext cloneCtx)
		{
			var t = (BlockVariableDeclarator) MemberwiseClone ();
			if (initializer != null)
				t.initializer = initializer.Clone (cloneCtx);

			return t;
		}*/
	}



}