namespace VSC.AST {

public interface INamedBlockVariable
	{
		/*Block Block { get; }
		Expression CreateReferenceExpression (ResolveContext rc, Location loc);
		bool IsDeclared { get; }
		bool IsParameter { get; }
		Location Location { get; }*/
	}

}