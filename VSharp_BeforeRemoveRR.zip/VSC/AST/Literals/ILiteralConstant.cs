namespace VSC.AST
{
    public interface ILiteralConstant
    {
        char[] ParsedValue { get; set; }
    }
}