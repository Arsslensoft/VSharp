using System;

namespace VSC.Base.GoldParser.Grammar {
	public enum CgtVersion {
		None = 0,
		V1_0 = 1,
		V5_0 = 5
	}
}
