using System;
using VSC.Base.GoldParser.Semantic;
namespace VSC.AST {
    public class FloatLiteral : LiteralExpression
    {
 
			[Rule("<Float Constant> ::= RealLiteral")]
			public FloatLiteral( Semantic _symbol131)
				{
				}
}
}
