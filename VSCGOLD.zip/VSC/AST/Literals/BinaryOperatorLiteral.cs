using System;
using VSC.Base.GoldParser.Semantic;
namespace VSC.AST { 
	public class BinaryOperatorLiteral : Semantic {
 
			[Rule("<Binary Operator Constant> ::= OperatorLiteralBinary")]
			public BinaryOperatorLiteral( Semantic _symbol120)
				{
				}
}
}
