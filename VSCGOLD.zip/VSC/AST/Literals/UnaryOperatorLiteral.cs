using System;
using VSC.Base.GoldParser.Semantic;
namespace VSC.AST { 
	public class UnaryOperatorLiteral : Semantic {
 
			[Rule("<Unary Operator Constant> ::= OperatorLiteralUnary")]
			public UnaryOperatorLiteral( Semantic _symbol121)
				{
				}
}
}
